def add_doc(value):
    def _doc(func):
        func.__doc__ = value
        return func

    return _doc


def append_doc(value):
    def _doc(func):
        func.__doc__ = "\n\n".join([func.__doc__, value])
        return func

    return _doc


from typing import Any, Callable, Optional, TypeVar
from textwrap import dedent

FuncType = Callable[..., Any]
F = TypeVar("F", bound=FuncType)


class Appender:
    """
    A function decorator that will append an addendum to the docstring
    of the target function.
    This decorator should be robust even if func.__doc__ is None
    (for example, if -OO was passed to the interpreter).
    Usage: construct a docstring.Appender with a string to be joined to
    the original docstring. An optional 'join' parameter may be supplied
    which will be used to join the docstring and addendum. e.g.
    
    add_copyright = Appender("Copyright (c) 2009", join='\n')

    @add_copyright
    def my_dog(has='fleas'):
        "This docstring will have a copyright below"
        pass
    Taken from pandas https://github.com/pandas-dev/pandas
    """

    addendum: Optional[str]

    def __init__(self, addendum: Optional[str], join: str = "", indents: int = 0):
        if indents > 0:
            self.addendum = indent(addendum, indents=indents)
        else:
            self.addendum = addendum
        self.join = join

    def __call__(self, func: F) -> F:
        func.__doc__ = func.__doc__ if func.__doc__ else ""
        self.addendum = self.addendum if self.addendum else ""
        docitems = [func.__doc__, self.addendum]
        func.__doc__ = dedent(self.join.join(docitems))
        return func


def indent(text: Optional[str], indents: int = 1) -> str:
    if not text or not isinstance(text, str):
        return ""
    jointext = "".join(["\n"] + ["    "] * indents)
    return jointext.join(text.split("\n"))